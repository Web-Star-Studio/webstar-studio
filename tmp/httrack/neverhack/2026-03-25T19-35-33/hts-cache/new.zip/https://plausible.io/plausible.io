<!DOCTYPE html>
<html lang="en" class="h-full plausible">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Plausible is a lightweight and open-source web analytics tool. Your website data is 100% yours and the privacy of your visitors is respected.">

    <meta name="robots" content="index, nofollow">

    <link rel="apple-touch-icon" sizes="180x180" href="/images/ee/apple-touch-icon-8ecdb958bc3d0c54930755663cc34525.png?vsn=d">
<link rel="icon" type="image/png" sizes="32x32" href="/images/ee/favicon-32x32-4453f8bca3f1ea04a9084aa5cb81f474.png?vsn=d">
<link rel="icon" type="image/png" sizes="16x16" href="/images/ee/favicon-16x16-dc007123f637eca918f9aae6c45bf5e9.png?vsn=d">

    <title>
      Plausible Analytics: Live Demo
    </title>
    <link rel="stylesheet" href="/css/app-a3c6e9c0e99ff425c610bb82e4f2df3e.css?vsn=d">
    <script blocking="rendering">
  (function(){
    var themePref = 'system';
    function reapplyTheme() {
      var darkMediaPref = window.matchMedia('(prefers-color-scheme: dark)').matches;
      var htmlRef = document.querySelector('html');
      var hcaptchaRefs = Array.from(document.getElementsByClassName('h-captcha'));

      var isDark = themePref === 'dark' || (themePref === 'system' && darkMediaPref);

      if (isDark) {
          htmlRef.classList.add('dark')
          hcaptchaRefs.forEach(function(ref) { ref.dataset.theme = "dark"; });
      } else {
          htmlRef.classList.remove('dark');
          hcaptchaRefs.forEach(function(ref) { ref.dataset.theme = "light"; });
      }
    }

    reapplyTheme();
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', reapplyTheme);
  })()
</script>
    
  <script id="dogfood-script" data-script-params="{&quot;custom_properties&quot;:{&quot;logged_in&quot;:false},&quot;domain_to_replace&quot;:null,&quot;location_override&quot;:null,&quot;capture_on_localhost&quot;:false,&quot;script_url&quot;:&quot;https://plausible.io/js/pa-6_srOGVV9SLMWJ1ZpUAbG.js&quot;}">
    var scriptParams = JSON.parse(document.currentScript.dataset.scriptParams)

    window.plausible=window.plausible||function(){(window.plausible.q=window.plausible.q||[]).push(arguments)},window.plausible.init=function(i){window.plausible.o=i||{}};var script=document.createElement("script");script.type="text/javascript",script.async=!0,script.src=scriptParams.script_url;var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(script,r);

    plausible.init({
      captureOnLocalhost: scriptParams.capture_on_localhost,
      customProperties: {
        ...scriptParams.custom_properties,
        browser_language: navigator.language || navigator.userLanguage
      },
      transformRequest: function (payload) {
        if (scriptParams.location_override) {
          payload.u = scriptParams.location_override
        } else if (scriptParams.domain_to_replace) {
          payload.u = payload.u.replace(scriptParams.domain_to_replace, ':dashboard')
        }
        return payload
      }
    })
  </script>

  </head>
  <body class="flex flex-col bg-gray-50 dark:bg-gray-950 h-full" style="">

      <nav class="relative z-20 py-8">
  <div class="container print:max-w-full">
    <nav class="relative flex items-center justify-between sm:h-10 md:justify-center">
      <div class="flex items-center flex-1 md:absolute md:inset-y-0 md:left-0">
        <a href="/">
          <img src="/images/ee/logo_dark-4ce532ac105c4615d6a2e51307c8fc28.svg?vsn=d" class="w-32 hidden dark:inline" alt="Plausible logo" loading="lazy">
          <img src="/images/ee/logo_light-38aed73a70daced020b53243966ed15e.svg?vsn=d" class="w-32 inline dark:hidden" alt="Plausible logo" loading="lazy">
        </a>
      </div>
      <div class="absolute inset-y-0 right-0 flex items-center justify-end">

            <ul class="flex" x-show="!document.cookie.includes('logged_in=true')">
              <li>
                <div class="inline-flex">
                  <a href="/login" class="font-medium text-gray-500 dark:text-gray-200 hover:text-gray-900 dark:hover:text-gray-100 focus:outline-hidden focus:text-gray-900 transition duration-150 ease-in-out">
                    Login
                  </a>
                </div>
                <div class="inline-flex ml-6 rounded-sm shadow-sm">
                  <a href="/register" class="inline-flex items-center justify-center px-5 py-2 text-base font-medium text-white bg-indigo-600 border border-transparent leading-6 rounded-md hover:bg-indigo-500 focus:outline-hidden focus:ring transition duration-150 ease-in-out">
                    Sign up
                  </a>
                </div>
              </li>
            </ul>

      </div>
    </nav>
  </div>
</nav>

        
  





    <main class="flex-1">
      <div class="container print:max-w-full" data-site-domain="plausible.io">
  <div x-cloak x-data="{show: !!sessionStorage.getItem(&#39;dashboard_seen_plausible.io&#39;)}" class="w-full px-4 text-sm font-bold text-center text-blue-900 bg-blue-200 rounded-sm transition" style="top: 91px" role="alert" x-bind:class="! show ? 'hidden' : ''" x-init="setTimeout(() =&gt; sessionStorage.removeItem(&#39;dashboard_seen_plausible.io&#39;), 3000)">
  <a href="/plausible.io/settings/email-reports" class="text-indigo-600 hover:text-indigo-700 dark:text-indigo-500 dark:hover:text-indigo-400 transition-colors duration-150 plausible-event-name=Weekly+Email+Note+Click">
  
    Get weekly traffic summaries by email →
  
</a>
</div>

  <div class="pt-6"></div>
  <div id="stats-react-container" style="overflow-anchor: none;" data-domain="plausible.io" data-offset="0" data-has-goals="true" data-conversions-opted-out="false" data-funnels-opted-out="false" data-props-opted-out="false" data-funnels-available="true" data-props-available="true" data-site-segments-available="true" data-revenue-goals="[]" data-funnels="[{&quot;id&quot;:9383,&quot;name&quot;:&quot;Blog to Email Newsletter&quot;,&quot;steps_count&quot;:2},{&quot;id&quot;:6328,&quot;name&quot;:&quot;Blog to Register&quot;,&quot;steps_count&quot;:3},{&quot;id&quot;:4,&quot;name&quot;:&quot;Registration &amp; Onboarding&quot;,&quot;steps_count&quot;:4}]" data-has-props="true" data-logged-in="false" data-stats-begin="2019-01-23" data-native-stats-begin="2019-01-23" data-embedded="" data-is-dbip="false" data-current-user-role="public" data-current-user-id="null" data-flags="{}" data-segments="[{&quot;id&quot;:5591,&quot;name&quot;:&quot;Non-customer traffic&quot;,&quot;type&quot;:&quot;site&quot;,&quot;inserted_at&quot;:&quot;2026-03-13T09:30:59&quot;,&quot;updated_at&quot;:&quot;2026-03-13T09:30:59&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;contains_not&quot;,&quot;event:page&quot;,[&quot;dashboard&quot;,&quot;sites&quot;,&quot;login&quot;,&quot;billing&quot;,&quot;settings&quot;,&quot;activate&quot;,&quot;:website&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:4028,&quot;name&quot;:&quot;Browser is Chrome&quot;,&quot;type&quot;:&quot;personal&quot;,&quot;inserted_at&quot;:&quot;2025-12-01T15:51:39&quot;,&quot;updated_at&quot;:&quot;2025-12-01T15:51:39&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;visit:browser&quot;,[&quot;Chrome&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:1843,&quot;name&quot;:&quot;Filters and Details usage&quot;,&quot;type&quot;:&quot;site&quot;,&quot;inserted_at&quot;:&quot;2025-06-25T11:54:59&quot;,&quot;updated_at&quot;:&quot;2025-07-01T10:54:08&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;contains&quot;,&quot;event:page&quot;,[&quot;/filter/&quot;,&quot;/pages&quot;,&quot;/exit-pages&quot;,&quot;/entry-pages&quot;,&quot;/utm-campaigns&quot;,&quot;/conversions&quot;,&quot;/operating-systems&quot;,&quot;/screen-sizes&quot;,&quot;/browsers&quot;,&quot;/channels&quot;,&quot;/regions&quot;,&quot;/cities&quot;,&quot;/countries&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:1897,&quot;name&quot;:&quot;Settings usage&quot;,&quot;type&quot;:&quot;site&quot;,&quot;inserted_at&quot;:&quot;2025-07-01T10:52:57&quot;,&quot;updated_at&quot;:&quot;2025-07-01T10:52:57&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;contains&quot;,&quot;event:page&quot;,[&quot;/settings/&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:1392,&quot;name&quot;:&quot;Trial signups from Google&quot;,&quot;type&quot;:&quot;site&quot;,&quot;inserted_at&quot;:&quot;2025-05-20T08:24:40&quot;,&quot;updated_at&quot;:&quot;2025-05-20T08:24:40&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;visit:source&quot;,[&quot;Google&quot;]],[&quot;is&quot;,&quot;event:goal&quot;,[&quot;Sign up for a trial&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:45,&quot;name&quot;:&quot;Trial signups from AI tools&quot;,&quot;type&quot;:&quot;site&quot;,&quot;inserted_at&quot;:&quot;2025-03-06T12:38:10&quot;,&quot;updated_at&quot;:&quot;2025-04-28T07:24:52&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;visit:source&quot;,[&quot;chatgpt.com&quot;,&quot;Perplexity&quot;,&quot;chat.mistral.ai&quot;,&quot;claude.ai&quot;,&quot;phind.com&quot;,&quot;chat.deepseek.com&quot;,&quot;you.com&quot;,&quot;grok.com&quot;]],[&quot;is&quot;,&quot;event:goal&quot;,[&quot;Sign up for a trial&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:39,&quot;name&quot;:&quot;Trial signups from Google search&quot;,&quot;type&quot;:&quot;personal&quot;,&quot;inserted_at&quot;:&quot;2025-03-06T12:17:57&quot;,&quot;updated_at&quot;:&quot;2025-04-25T20:59:17&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;visit:source&quot;,[&quot;Google&quot;]],[&quot;is&quot;,&quot;event:goal&quot;,[&quot;Sign up for a trial&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:114,&quot;name&quot;:&quot;Goal is Visit /register&quot;,&quot;type&quot;:&quot;personal&quot;,&quot;inserted_at&quot;:&quot;2025-03-07T09:32:55&quot;,&quot;updated_at&quot;:&quot;2025-03-07T09:32:55&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;event:goal&quot;,[&quot;Visit /register&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null},{&quot;id&quot;:25,&quot;name&quot;:&quot;Organic Traffic Signups&quot;,&quot;type&quot;:&quot;personal&quot;,&quot;inserted_at&quot;:&quot;2025-03-06T11:53:49&quot;,&quot;updated_at&quot;:&quot;2025-03-06T11:53:49&quot;,&quot;segment_data&quot;:{&quot;filters&quot;:[[&quot;is&quot;,&quot;visit:channel&quot;,[&quot;Organic Search&quot;]],[&quot;is&quot;,&quot;event:goal&quot;,[&quot;Sign up for a trial&quot;]]],&quot;labels&quot;:{}},&quot;owner_id&quot;:null,&quot;owner_name&quot;:null}]" data-valid-intervals-by-period="{&quot;12mo&quot;:[&quot;day&quot;,&quot;week&quot;,&quot;month&quot;],&quot;24h&quot;:[&quot;minute&quot;,&quot;hour&quot;],&quot;28d&quot;:[&quot;day&quot;,&quot;week&quot;],&quot;30d&quot;:[&quot;day&quot;,&quot;week&quot;],&quot;6mo&quot;:[&quot;day&quot;,&quot;week&quot;,&quot;month&quot;],&quot;7d&quot;:[&quot;hour&quot;,&quot;day&quot;],&quot;91d&quot;:[&quot;day&quot;,&quot;week&quot;,&quot;month&quot;],&quot;all&quot;:[&quot;week&quot;,&quot;month&quot;],&quot;custom&quot;:[&quot;day&quot;,&quot;week&quot;,&quot;month&quot;],&quot;day&quot;:[&quot;minute&quot;,&quot;hour&quot;],&quot;month&quot;:[&quot;day&quot;,&quot;week&quot;],&quot;realtime&quot;:[&quot;minute&quot;],&quot;year&quot;:[&quot;day&quot;,&quot;week&quot;,&quot;month&quot;]}" data-is-consolidated-view="false" data-consolidated-view-available="true" data-team-identifier="ef83ae04-ab7a-4b62-a2a6-76970f94c08c" data-limited-to-segment-id="null">
  </div>
  <div id="modal_root"></div>

    <div class="py-12 lg:py-16 lg:flex lg:items-center lg:justify-between">
      <h2 class="text-3xl font-extrabold tracking-tight text-gray-900 leading-9 sm:text-4xl sm:leading-10 dark:text-gray-100">
        Want these stats for your website? <br>
        <span class="text-indigo-600">Start your free trial today.</span>
      </h2>
      <div class="flex mt-8 lg:shrink-0 lg:mt-0">
        <div class="inline-flex shadow-sm rounded-md">
          <a href="/register" class="inline-flex items-center justify-center px-5 py-3 text-base font-medium text-white bg-indigo-600 border border-transparent leading-6 rounded-md hover:bg-indigo-500 focus:outline-hidden focus:ring transition duration-150 ease-in-out">
            Get started
          </a>
        </div>
        <div class="inline-flex ml-3 shadow-xs rounded-md">
          <a href="/" class="inline-flex items-center justify-center px-5 py-3 text-base font-medium text-indigo-600 bg-white border border-transparent leading-6 rounded-md dark:text-gray-100 dark:bg-gray-800 hover:text-indigo-500 dark:hover:text-indigo-500 focus:outline-hidden focus:ring transition duration-150 ease-in-out">
            Learn more
          </a>
        </div>
      </div>
    </div>

</div>
    </main>


      <div class="mt-24 bg-gray-800 dark:bg-gray-900">
  <div class="container px-4 py-12 sm:px-6 lg:py-16 lg:px-8">
    <div class="xl:grid xl:grid-cols-3 xl:gap-8">
      <div class="my-8 xl:my-0">
        <h4 class="font-semibold tracking-wider text-gray-300 leading-5">
          <img src="/images/ee/logo_dark-4ce532ac105c4615d6a2e51307c8fc28.svg?vsn=d" class="inline-block w-32 mr-1" alt="Plausible logo" loading="lazy">
        </h4>
        <p class="mt-4 text-base text-gray-400 leading-6">

            Made and hosted in the EU <span class="text-lg">🇪🇺</span> <br>
            Solely funded by our subscribers.


        </p>
      </div>
      <div class="grid grid-cols-2 gap-8 xl:col-span-2">
        <div class="md:grid md:grid-cols-2 md:gap-8 print:hidden">
          <div>
            <h4 class="text-sm font-semibold tracking-wider text-gray-400 uppercase leading-5">
              Getting started
            </h4>
            <ul class="mt-4">
              <li>
                <a rel="noreferrer" href="https://plausible.io/docs/integration-guides" class="text-base text-gray-300 leading-6 hover:text-white">
                  Integration guides
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/wordpress-analytics-plugin" class="text-base text-gray-300 leading-6 hover:text-white">
                  WordPress plugin
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/troubleshoot-integration" class="text-base text-gray-300 leading-6 hover:text-white">
                  Troubleshooting
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/script-extensions" class="text-base text-gray-300 leading-6 hover:text-white">
                  Script extensions
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/google-analytics-import" class="text-base leading-6 text-gray-300 hover:text-white">
                  Import stats
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/google-search-console-integration" class="text-base leading-6 text-gray-300 hover:text-white">
                  Search Console
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/users-roles" class="text-base leading-6 text-gray-300 hover:text-white">
                  Invite team members
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs/excluding" class="text-base leading-6 text-gray-300 hover:text-white">
                  Exclude traffic
                </a>
              </li>
            </ul>
          </div>
          <div class="mt-32 md:mt-0">
            <h4 class="text-sm font-semibold tracking-wider text-gray-400 uppercase leading-5">
              Help guides
            </h4>
            <ul class="mt-4">
              <li>
                <a rel="noferrer" href="https://plausible.io/docs/compare-stats" class="text-base text-gray-300 leading-6 hover:text-white">
                  Compare stats
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/filters-segments" class="text-base text-gray-300 leading-6 hover:text-white">
                  Segment audience
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/manual-link-tagging" class="text-base text-gray-300 leading-6 hover:text-white">
                  Track campaigns
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/goal-conversions" class="text-base text-gray-300 leading-6 hover:text-white">
                  Event conversions
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/funnel-analysis" class="text-base text-gray-300 leading-6 hover:text-white">
                  Funnel analysis
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/ecommerce-revenue-tracking" class="text-base text-gray-300 leading-6 hover:text-white">
                  Revenue attribution
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/custom-props/introduction" class="text-base text-gray-300 leading-6 hover:text-white">
                  Custom properties
                </a>
              </li>
              <li class="mt-4">
                <a rel="noferrer" href="https://plausible.io/docs/proxy/introduction" class="text-base text-gray-300 leading-6 hover:text-white">
                  Bypass adblockers
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="md:grid md:grid-cols-2 md:gap-8 print:hidden">
          <div>
            <h4 class="text-sm leading-5 font-semibold tracking-wider text-gray-400 uppercase">
              Community
            </h4>
            <ul class="mt-4">
              <li>
                <a rel="noreferrer" href="https://plausible.io/changelog" class="text-base leading-6 text-gray-300 hover:text-white">
                  What's new
                </a>
              </li>
              <li class="mt-4">
                <a ref="noreferrer" target="_blank" href="https://plausible.io/status" class="text-base leading-6 text-gray-300 hover:text-white">
                  Status
                </a>
              </li>
              <li class="mt-4">
                <a ref="noreferrer" href="https://plausible.io/blog" class="text-base leading-6 text-gray-300 hover:text-white">
                  Blog
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/docs" class="text-base leading-6 text-gray-300 hover:text-white">
                  Documentation
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" target="_blank" href="https://github.com/plausible/analytics" class="text-base leading-6 text-gray-300 hover:text-white">
                  GitHub
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" target="_blank" href="https://twitter.com/plausiblehq" class="text-base leading-6 text-gray-300 hover:text-white">
                  Twitter
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" target="_blank" rel="me" href="https://fosstodon.org/@plausible" class="text-base leading-6 text-gray-300 hover:text-white">
                  Mastodon
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" target="_blank" href="https://www.linkedin.com/company/plausible-analytics/" class="text-base leading-6 text-gray-300 hover:text-white">
                  LinkedIn
                </a>
              </li>
            </ul>
          </div>
          <div class="mt-12 md:mt-0">
            <h4 class="text-sm leading-5 font-semibold tracking-wider text-gray-400 uppercase">
              Company
            </h4>
            <ul class="mt-4">
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/about" class="text-base leading-6 text-gray-300 hover:text-white">
                  About
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/contact" class="text-base leading-6 text-gray-300 hover:text-white">
                  Contact
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/privacy" class="text-base leading-6 text-gray-300 hover:text-white">
                  Privacy
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/data-policy" class="text-base leading-6 text-gray-300 hover:text-white">
                  Data policy
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/terms" class="text-base leading-6 text-gray-300 hover:text-white">
                  Terms
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/dpa" class="text-base leading-6 text-gray-300 hover:text-white">
                  DPA
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/security" class="text-base leading-6 text-gray-300 hover:text-white">
                  Security
                </a>
              </li>
              <li class="mt-4">
                <a rel="noreferrer" href="https://plausible.io/imprint" class="text-base leading-6 text-gray-300 hover:text-white">
                  Imprint
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

    <script type="text/javascript" src="/js/app-a35e5bd693ad07a91f7be79b600215fa.js?vsn=d">
    </script>

      <script type="text/javascript" src="/js/dashboard-5e06c2a4b744e9f6f4a9d4a4d53bb889.js?vsn=d">
      </script>

  </body>
</html>